def lambdaHandler(event, context):
    print('Hello World v1.0')
